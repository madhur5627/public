#include<stdio.h>
#include<stdlib.h>
void main()
{
 int n,m,i,j,op=0,sum=0;
 printf("enter number of processes");
	scanf("%d",&n);
 printf("enter number of resources");
	scanf("%d",&m);

 int allocation[n][m],max[n][m],need[n][m],available[m];

printf("enter allocations :\n");
 		for(i=0;i<n;i++)
			for(j=0;j<m;j++)
			{
			 printf("\nenter matrix value:");
			 scanf("%d",&allocation[i][j]); 
			}

 printf("enter max matrix of processes:");
 for(i=0;i<n;i++)
	for(j=0;j<m;j++)
	{
	 printf("\nenter matrix value :");
		scanf("%d",&max[i][j]); 
	}

 do{

	printf("\n1.enter available\n2.display allocation and max\n3.find need and display\n4.display availavle\n5.exit\nenter choice : ");
  	scanf("%d",&op);

 switch(op)
	{
	case 1:
		printf("enter available resources of all processes:\n");
	 	for(i=0;i<m;i++)
		scanf("%d",&available[i]);
		break;
	case 2: printf("allocation matrix is :\n");
  		for(i=0;i<n;i++)
		{
			for(j=0;j<m;j++)
			 printf("%d\t",allocation[i][j]); 
		printf("\n");
      		}
 		printf("max matrix is :\n");
  		for(i=0;i<n;i++)
		{
		  	for(j=0;j<m;j++)
	 	  	printf("%d\t",max[i][j]); 
		  printf("\n");
      		}
		break;
	case 3: printf("need matrix is :\n");
  		for(i=0;i<n;i++)
		{
		  for(j=0;j<m;j++)
		{
	 	need[i][j]=max[i][j]-allocation[i][j];
	 	printf("%d\t",need[i][j]); 
		}
		printf("\n");
      		}
		break;
	case 4:  printf("available resources of processes:\n");
		 for(i=0;i<m;i++)
		 {
		printf("resources available of R%d - %d\n",i,available[i]); 
		}
		break;
 	case 5:exit(0);

	 }
	}while(op>0&&op<6);
}
