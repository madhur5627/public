#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct process{
  int num;
  int arrival_time;
  int burst_time;
  int tat;
  int wait_time;
}process;

int main()
{
 int n,i,j;
int tt=0,wait=0,total=0;
  
   printf("enter total number of processes you want :");
 scanf("%d",&n);
 struct process *arr=malloc (n* sizeof(process));
 for(i=0;i<n;i++)
 {
   printf("enter arrival and burst time of process %d ",i+1);
   scanf("%d %d",&arr[i].arrival_time,&arr[i].burst_time);
	arr[i].num=i+1;
 }

 for(i=0;i<n;i++)
  {
   for(j=i+1;j<n;j++)
	{
		if(arr[i].arrival_time>arr[j].arrival_time)
		{
		struct process temp;
			temp=arr[i];
			arr[i]=arr[j];
			arr[j]=temp;
		}
		if(arr[i].arrival_time==arr[j].arrival_time&&arr[j].burst_time<arr[i].burst_time)
		{
		struct process temp;
			temp=arr[i];
			arr[i]=arr[j];
			arr[j]=temp;
		}
	}
  }

 int current_time=arr[0].arrival_time;
 for(i=0;i<n;i++)
  {
	for(j=i+1;j<n;j++)
	{
		if(current_time>=arr[j].arrival_time&&arr[j].burst_time<arr[i].burst_time)
		{
			struct process temp;
			temp=arr[i];
			arr[i]=arr[j];
			arr[j]=temp;
	     
	 		}		
	}
	current_time+=arr[i].burst_time;
  }
  
  int ideal[n];
 for(i=0;i<n;i++)
 ideal[i]=0;

current_time=0;
 for(i=0;i<n;i++)
	{
	    if(arr[i].arrival_time>current_time)
		{
		    ideal[i]=1;
		    current_time=arr[i].arrival_time;
		}
	  arr[i].wait_time=current_time-arr[i].arrival_time;
	wait+=arr[i].wait_time;
	  arr[i].tat=arr[i].burst_time+arr[i].wait_time;
	tt+=arr[i].tat;
	  current_time+=arr[i].burst_time;
	}
 
  printf("gantt chart :\n");
  for(i=0;i<n;i++)
 {
     if(ideal[i]!=0)
     printf(" ideal-->");
     printf(" process %d -->",arr[i].num);
 }

  printf("\nwaiting time and TAT are as follow :\n");
printf("process     burst     arrival     waiting     turnaround\n");
for(i=0;i<n;i++)
	printf("%d     		%d     	   %d     	%d     	%d     \n",
arr[i].num,arr[i].burst_time,arr[i].arrival_time,arr[i].wait_time,arr[i].tat);

printf("average turn around is %d\n and avg waiting is %d :",tt/n,wait/n);
return 0;
}


