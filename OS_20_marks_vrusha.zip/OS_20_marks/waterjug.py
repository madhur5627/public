from collections import deque

def is_visited(state, visited):
    return state in visited

def next_states(x, y, m, n):
    possible_states = []

    possible_states.append((m, y))
    possible_states.append((x, n))
    possible_states.append((0, y))
    
    possible_states.append((x, 0))
    
    if x + y >= n:
        possible_states.append((x - (n - y), n))
    else:
        possible_states.append((0, x + y)) 

   
    if x + y >= m:
        possible_states.append((m, y - (m - x)))  
    else:
        possible_states.append((x + y, 0))
        
    return possible_states


def water_jug_solver(m, n, d):
    initial_state = (0, 0)
    goal_state = (0, d)  
    
    queue = deque([(initial_state, [])])
    
    visited = set()
    visited.add(initial_state)
    
    while queue:
        (x, y), path = queue.popleft()
        
        if (x == 0 and y == d):
            return path + [(x, y)]
        
        for state in next_states(x, y, m, n):
            if not is_visited(state, visited):
                visited.add(state)
                queue.append((state, path + [(x, y)]))
    return []


m = 4
n = 3
d = 2 

solution = water_jug_solver(m, n, d)

print("Steps to reach the goal:")
for step in solution:
    print(step)
