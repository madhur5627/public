#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h>
void main()
{
 int n,m,i,j,k,y,sum,flag;
 
 printf("enter number of processes : ");
	scanf("%d",&n);
 printf("enter number of resources : ");
	scanf("%d",&m);

 int allocation[n][m];
 int need[n][m];
 int max[n][m];
 int available[m];
 int finish[n];

 printf("enter allocations : \n");
 for(i=0;i<n;i++)
	for(j=0;j<m;j++)
	{
	 printf("enter instance of R%d allocated to P%d : ",j,i);
		scanf("%d",&allocation[i][j]); 
	}

 printf("enter max matrix:\n");
 for(i=0;i<n;i++)
	for(j=0;j<m;j++)
	{
	 printf("enter maximum instance of R%d by P%d :",j,i);
		scanf("%d",&max[i][j]); 
	}

    for(i=0;i<n;i++)
        for(j=0;j<m;j++)
            need[i][j]=max[i][j]-allocation[i][j];

    printf("need matrix is :\n");
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
            printf("%d\t",need[i][j]);
        printf("\n");
    }

  printf("enter available resources of processes:\n");
	 for(i=0;i<m;i++)
	 {
	    printf("resource %d : ",i);
		scanf("%d",&available[i]); 
	 }

     int avl[m];
     for(i=0;i<m;i++)//duplicating the original available resource values
     avl[i]=available[i];

 for(i=0;i<n;i++)
 finish[i]=0;

int ans[n];
int index=0;
for(k=0;k<n;k++)
    for(i=0;i<n;i++)
        if(finish[i]==0)
        {
            flag=0;
            for(j=0;j<m;j++)
                if(need[i][j]>available[j])
                {
                    flag=1;
                    break;
                }
            if(flag==0)
            {
                for(y=0;y<m;y++)
                available[y]+=allocation[i][y];
                finish[i]=1;
                ans[index++]=i;
            }
        }
    
 for(i=0;i<n;i++)
    if(finish[i]==0){
        printf("deadlock is present");
        exit(0);
    }   
 
 printf("deadlock is not present and safe sequence is :\n");
 for(i=0;i<n;i++)
 printf("process %d-->",ans[i]);

//question C
int num;
 int state[m];
 printf("enter process number who is requesting :");
 scanf("%d",&num);
 printf("enter the request :");
 
 for(i=0;i<m;i++)
 scanf("%d",&state[i]);

for(i=0;i<m;i++)//checking conditions 
{
    if(state[i]<=need[num][i]&&state[i]<=avl[i])
    continue;
        printf("system wont be safe so permission can't be granted");
        exit(0);
}

for(i=0;i<n;i++)//making changes on table
{
    allocation[num][i]+=state[i];
    avl[i]-=state[i];
    need[num][i]-=state[i];
}

for(i=0;i<n;i++)
 finish[i]=0;
// again checking for deadlock
for(k=0;k<n;k++)
    for(i=0;i<n;i++)
        if(finish[i]==0)
        {
            flag=0;
            for(j=0;j<m;j++)
                if(need[i][j]>avl[j])
                {
                    flag=1;
                    break;
                }
            if(flag==0)
            {
                for(y=0;y<m;y++)
                avl[y]+=allocation[i][y];
                finish[i]=1;
                ans[index++]=i;
            }
        }
    
 for(i=0;i<n;i++)
    if(finish[i]==0){
        printf("system wont be safe so request cant be granted");
        exit(0);
    }   
 
 printf("system is safe and request can be granted immediately :\n");

}
