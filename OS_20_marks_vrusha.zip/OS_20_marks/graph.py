import heapq

graph = {
    'A': [('B', 6), ('F', 3)],
    'B': [('A', 6), ('C', 3), ('D', 2)],
    'C': [('B', 3), ('D', 1), ('E', 5)],
    'D': [('B', 2), ('C', 1), ('E', 8)],
    'E': [('C', 5), ('D', 8), ('J', 5)],
    'F': [('H', 7), ('G', 1)],
    'G': [('I', 3), ('F', 1)],
    'H': [('F', 7), ('I', 2)],
    'I': [('G',3),('E',5),('H',2),('J',3)],
    'J': [('I', 3),('E',5)]
}

heuristics = {
    'A': 10, 'B': 8, 'C': 5, 'D': 7,
    'E': 3, 'F': 6, 'G': 5, 'H': 1, 'J': 0, 'I':1
}

def a_star_search(graph, heuristics, start, goal):
    open_list = []
    heapq.heappush(open_list, (0 + heuristics[start], 0, start, [start]))

    visited = set()

    while open_list:
        _, g, current_node, path = heapq.heappop(open_list)

        if current_node in visited:
            continue
        
        if current_node == goal:
            return path, g
        
        visited.add(current_node)

        for neighbor, cost in graph.get(current_node, []):
            if neighbor not in visited:
                new_g = g + cost
                f = new_g + heuristics[neighbor]
                heapq.heappush(open_list, (f, new_g, neighbor, path + [neighbor]))
    
    return None, float('inf')

path, cost = a_star_search(graph, heuristics, 'A', 'J')
print(f"Most cost-effective path: {path}")
print(f"Total cost: {cost}")


