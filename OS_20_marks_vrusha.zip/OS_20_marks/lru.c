#include<stdio.h>
int main()
{
    int n, m, i, j, k;
    int fault = 0;
    printf("Enter the number of pages: ");
    scanf("%d", &n);
    int page[n];
    printf("Enter the number of frames: ");
    scanf("%d", &m);
    int frame[m];
    int index[m];
    for (i = 0; i < m; i++) {
        frame[i] = -1;
        index[i] = -1;
    }
    for (i = 0; i < n; i++) {
        printf("Enter page %d: ", i + 1);
        scanf("%d", &page[i]);
    }
    for (i = 0; i < n; i++) {
        int present = 0;
        for (j = 0; j < m; j++) {
            if (page[i] == frame[j]) {
                present = 1;
                index[j] = i;
                break;
            }
        }
        if (!present) {
            fault++;
            int minindex = 0;
            int min = n;
            for (k = 0; k < m; k++) {
                if (frame[k] == -1) {
                    frame[k] = page[i];
                    index[k] = i;
                    break;
                }
                if (index[k] < min) {
                    min = index[k];
                    minindex = k;
                }
            }
            if (k == m) {
                frame[minindex] = page[i];
                index[minindex] = i;
            }
        }
        printf("Frame: ");
        for (j = 0; j < m; j++) {
            if (frame[j] == -1)
                printf("- ");
            else
                printf("%d ", frame[j]);
        }
        printf("\n");
    }
    printf("Total page faults: %d\n", fault);
    return 0;
}