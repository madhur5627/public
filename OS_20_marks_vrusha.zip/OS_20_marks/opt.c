#include<stdio.h>
int main()
{
    int n, m, i, j, k;
    int fault = 0;
    printf("Enter the number of pages: ");
    scanf("%d", &n);
    int page[n];
    printf("Enter the number of frames: ");
    scanf("%d", &m);
    int frame[m];
    for (i = 0; i < m; i++)
        frame[i] = -1;
    for (i = 0; i < n; i++) {
        printf("Enter page %d: ", i + 1);
        scanf("%d", &page[i]);
    }
     
    for (i = 0; i < n; i++) {
        int present = 0;
        for (j = 0; j < m; j++) {
            if (page[i] == frame[j]) {
                present = 1;
                break;
            }
        }
        if (!present) {
            fault++;
            int maxindex = 0;
            int maxdistance = 0;
            for (k = 0; k < m; k++) {
                int distance = n;
                for (int l = i + 1; l < n; l++) {
                    if (frame[k] == page[l]) {
                        distance = l - i;
                        break;
                    }
                }
                if (distance > maxdistance) {
                    maxdistance = distance;
                    maxindex = k;
                }
            }
            frame[maxindex] = page[i];
        }
        printf("Frame: ");
        for (j = 0; j < m; j++) {
            if (frame[j] == -1)
                printf("- ");
            else
                printf("%d ", frame[j]);
        }
        printf("\n");
    }
    printf("Total page faults: %d\n", fault);
   return 0;
}