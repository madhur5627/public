#include<stdio.h>
#include<sys/types.h>
#include<stdlib.h>
 int main(){
    printf("child process id is %d",getpid());
    exit(0);
}