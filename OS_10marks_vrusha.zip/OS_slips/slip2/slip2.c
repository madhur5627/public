#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<unistd.h>
//execv
int main(){
    printf("parent process id is %d",getpid());
    char *argv[]={"child",NULL};
    execv("./child",argv);

    perror("execv failed:");
    return 0;
}
//execvp
int main(){
    printf("parent process id is %d",getpid());
    char *argv[]={"child",NULL};
    execvp("./child",argv);

    perror("execv failed:");
    return 0;
}
//execl
int main(){
    printf("parent process id is %d",getpid());
    execl("./child","child",NULL);

    perror("execv failed:");
    return 0;
}