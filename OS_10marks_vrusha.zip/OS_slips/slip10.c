#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<unistd.h>
int main()
{
	pid_t pid=fork();
	if(pid==0)
	{
	printf("\nthis is child process and its id is %d and PPID is %d \n",getpid(),getppid());
	 sleep(5);
	printf("\nthis is orphan child process and its id is %d and PPID is %d \n",getpid(),getppid());
	}
	else
	{
	  printf("parent process and its id is %d\n",getpid());
	  sleep(1);
	 printf("parent is terminating...");
	 exit(0);
	}
	return 0;
}