#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int main() {
    pid_t pid = fork(); 

    if (pid == 0) {
        printf("Child process (PID: %d) is executing 'ls' command...\n", getpid());
        execl("/bin/ls", "ls", NULL);
        printf("child finished");
    } 
    else {
        printf("Parent process (PID: %d) is going to sleep for 5 seconds...\n", getpid());
        sleep(5); 
        printf("Parent process woke up and is terminating.\n");
    }
    return 0;
}