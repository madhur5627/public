#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<unistd.h>
#include<sys/wait.h>
#include<sys/resource.h>

int main(){
    pid_t pid=fork();

    if(pid==0)
    {
        printf("in child process :\n");
        printf("priority of child process is %d \n",getpriority(PRIO_PROCESS,getpid()));
        int new_priority=nice(1);
        printf("new child process priority is %d \n",new_priority);
        printf("child finished\n");
    }
    else{
        printf("in parent process \n");
        printf("parent wait for child to complete...\n");
        wait(NULL);
        printf("parent finished");
    }
    return 0;
}
