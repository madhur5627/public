#include<stdio.h>
#include<sys/types.h>
#include<stdlib.h>

int main(){
    pid_t pid=fork();
    if(pid==0)
    {
        printf("child process id is :%d",getpid());
        printf("hello world");
    }
    else{
        printf("parent process id is :%d",getpid());
        printf("hi");
    }
    return 0;
}