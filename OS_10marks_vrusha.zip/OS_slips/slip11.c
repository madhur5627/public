#include<stdio.h>
#include<time.h>
int main()
{
int i;
	clock_t start_time,end_time;
	double execution_time;

	start_time=clock();

	for(i=0;i<1000000000ULL;i++)
		i*i;

	end_time=clock();

	execution_time=(double)(end_time-start_time)/CLOCKS_PER_SEC;
  
	printf("execution time is %f seconds",execution_time);

}
