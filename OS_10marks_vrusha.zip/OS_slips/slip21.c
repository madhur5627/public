#include<stdio.h>

void main()
{
 int n,m,i,j;
 printf("enter number of processes");
	scanf("%d",&n);
 printf("enter number of resources");
	scanf("%d",&m);

 int allocation[n][m];
 printf("enter allocations :\n");
 for(i=0;i<n;i++)
	for(j=0;j<m;j++)
	{
	 printf("\nenter allocation :");
		scanf("%d",&allocation[i][j]); 
	}

 int max[n][m];
 printf("enter max need matrix of processes:\n");
 for(i=0;i<n;i++)
	for(j=0;j<m;j++)
	{
	 printf("\nenter max need :");
		scanf("%d",&max[i][j]); 
	}

 int need[n][m];
  printf("minimum number of resources needed to avoid deadlock are :\n");
  for(i=0;i<n;i++)
	{
	for(j=0;j<m;j++)
	{
	 need[i][j]=max[i][j]-allocation[i][j];
	 printf("%d\t",need[i][j]); 
  
	}
	printf("\n");
	}
}