
const express = require("express")

const app = express()

app.get("/",(req,res)=>{
   res.send("Server Running")
})

app.get("/employees",(req,res)=>{
   res.json([
      {name:"Harsh",salary:60000}
   ])
})

app.listen(5000,()=>{
 console.log("Server Started")
})
