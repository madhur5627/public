
import { useState } from "react"

function EmployeeForm(){

 const [name,setName] = useState("")
 const [salary,setSalary] = useState("")

 return(
  <div>
   <input
    type="text"
    placeholder="Name"
    onChange={(e)=>setName(e.target.value)}
   />

   <input
    type="number"
    placeholder="Salary"
    onChange={(e)=>setSalary(e.target.value)}
   />

   <button>Add Employee</button>
  </div>
 )
}

export default EmployeeForm
