
# Employee Management System - Beginner Step Guide

## Step 1 - Create React Frontend

```bash
npx create-react-app frontend
cd frontend
npm start
```

---

## Step 2 - Install React Router

```bash
npm install react-router-dom
```

---

## Step 3 - Create Components

Create:
- Navbar.js
- EmployeeForm.js
- EmployeeList.js

---

## Step 4 - Employee Form Example

```javascript
import { useState } from "react"

function EmployeeForm(){

 const [name,setName] = useState("")
 const [salary,setSalary] = useState("")

 return(
  <div>
   <input
    type="text"
    placeholder="Name"
    onChange={(e)=>setName(e.target.value)}
   />

   <input
    type="number"
    placeholder="Salary"
    onChange={(e)=>setSalary(e.target.value)}
   />

   <button>Add Employee</button>
  </div>
 )
}

export default EmployeeForm
```

---

## Step 5 - Display Employee List

```javascript
const employees = [
 {name:"Harsh",salary:60000},
 {name:"Rahul",salary:30000}
]

employees.map((emp)=>{
 return(
   <h1>{emp.name}</h1>
 )
})
```

---

## Step 6 - High Salary Condition

```javascript
{
 emp.salary > 50000 && <p>High Salary</p>
}
```

---

## Step 7 - Create Backend

```bash
mkdir backend
cd backend
npm init -y
npm install express cors mongoose
```

---

## Step 8 - Simple Express Server

```javascript
const express = require("express")

const app = express()

app.get("/",(req,res)=>{
   res.send("Server Running")
})

app.listen(5000,()=>{
 console.log("Server Started")
})
```

Run:
```bash
node server.js
```

---

## Step 9 - GET API

```javascript
app.get("/employees",(req,res)=>{
  res.json([
   {name:"Harsh",salary:60000}
  ])
})
```

---

## Step 10 - React Fetch API

```javascript
fetch("http://localhost:5000/employees")
```

---

## Important Viva Questions

1. What is React?
2. What is useState?
3. What is API?
4. What is CRUD?
5. What is MongoDB?

---

## Project Flow

React Form
↓
API Call
↓
Express Backend
↓
MongoDB
↓
Data Saved
